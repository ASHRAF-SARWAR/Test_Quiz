#include<iostream>
#include<conio.h>
#include<windows.h>
using namespace std;
struct student{
	char Name[20],roll[20];
	int marks;
};
student st;
void math()
{
	char choice;
    cout<<"Question no #1 \n 3*2+2/2=?"<<endl;
    cout<<"a) 7"<<endl;
    cout<<"b) 4"<<endl;
    cout<<"c) 6"<<endl;
    cout<<"d) 3"<<endl;
    choice=getch();
    if(choice=='a'||choice=='A')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
	}
    cout<<"Question no #2 \n factorial of 6?"<<endl;
    cout<<"a) 120"<<endl;
    cout<<"b) 60"<<endl;
    cout<<"c) 360"<<endl;
    cout<<"d) 720"<<endl;
    choice=getch();
    if(choice=='d'||choice=='D')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
	}
    cout<<"Question no #3 \n cos60=?"<<endl;
    cout<<"a) 1"<<endl;
    cout<<"b) 0.866"<<endl;
    cout<<"c) 0.70"<<endl;
    cout<<"d) 0.5"<<endl;
    choice=getch();
    if(choice=='d'||choice=='D')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
}
    cout<<"Question no #4 \n slope infinty means ?"<<endl;
    cout<<"a) straight line"<<endl;
    cout<<"b) horizental line"<<endl;
    cout<<"c) vertical line"<<endl;
    cout<<"d) chord"<<endl;
    choice=getch();
    if(choice=='c'||choice=='C')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
	}
    cout<<"Question no #5 \n 1/0=?"<<endl;
    cout<<"a) infinity"<<endl;
    cout<<"b) zero"<<endl;
    cout<<"c) hunderd"<<endl;
    cout<<"d) 1"<<endl;
    choice=getch();
    if(choice=='a'||choice=='A')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
	}

}
void eng() {
	
	char choice;
    cout<<"Question no #1 \n choose the correct spell?"<<endl;
    cout<<"a) village"<<endl;
    cout<<"b) vellage"<<endl;
    cout<<"c) vilage"<<endl;
    cout<<"d) velag"<<endl;
    choice=getch();
    if(choice=='a'||choice=='A')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
	}
    cout<<"Question no #2 \n synonym of antique?"<<endl;
    cout<<"a) New"<<endl;
    cout<<"b) Current"<<endl;
    cout<<"c) Good"<<endl;
    cout<<"d) Ancient"<<endl;
    choice=getch();
    if(choice=='d'||choice=='D')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
	}
    cout<<"Question no #3 \n Who is writer of Good by Chips novel ?"<<endl;
    cout<<"a) Sheks pair"<<endl;
    cout<<"b) Mustafa kamal"<<endl;
    cout<<"c) rober"<<endl;
    cout<<"d) James Hilton"<<endl;
    choice=getch();
    if(choice=='d'||choice=='D')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
}
    cout<<"Question no #4 \n Ali is sitting ......... tree ?"<<endl;
    cout<<"a) By"<<endl;
    cout<<"b) On"<<endl;
    cout<<"c) Against"<<endl;
    cout<<"d) In"<<endl;
    choice=getch();
    if(choice=='c'||choice=='C')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
	}
    cout<<"Question no #5 \n It is ....... since morning?"<<endl;
    cout<<"a) Raining"<<endl;
    cout<<"b) Rain"<<endl;
    cout<<"c) Rained"<<endl;
    cout<<"d) Raines"<<endl;
    choice=getch();
    if(choice=='a'||choice=='A')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
	}


}
void phy() 
	{
	char choice;
    cout<<"Question no #1 \n Which one is insulator?"<<endl;
    cout<<"a) Iron"<<endl;
    cout<<"b) Gold"<<endl;
    cout<<"c) Wood"<<endl;
    cout<<"d) Copper"<<endl;
    choice=getch();
    if(choice=='c'||choice=='C')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
	}
    cout<<"Question no #2 \n Power = ?"<<endl;
    cout<<"a) ma"<<endl;
    cout<<"b) qv"<<endl;
    cout<<"c) rf"<<endl;
    cout<<"d) F.V"<<endl;
    choice=getch();
    if(choice=='d'||choice=='D')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
	}
    cout<<"Question no #3 \n cos60=?"<<endl;
    cout<<"a) 1"<<endl;
    cout<<"b) 0.866"<<endl;
    cout<<"c) 0.70"<<endl;
    cout<<"d) 0.5"<<endl;
    choice=getch();
    if(choice=='d'||choice=='D')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
}
    cout<<"Question no #4 \n Capacitance of capacitor increas?"<<endl;
    cout<<"a) By increasing voltages"<<endl;
    cout<<"b) By decreasing charges"<<endl;
    cout<<"c) By increaing diatance b/w plates"<<endl;
    cout<<"d) None"<<endl;
    choice=getch();
    if(choice=='c'||choice=='C')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
	}
    cout<<"Question no #5 \n Magnetic field lines are uniform?"<<endl;
    cout<<"a) False"<<endl;
    cout<<"b) True"<<endl;
    cout<<"c) None Uniform"<<endl;
    cout<<"d) Parallel"<<endl;
    choice=getch();
    if(choice=='a'||choice=='A')
    {
    	cout<<" Your answer is correct"<<endl;
    	st.marks=st.marks+4;
	}
	else
	{
		cout<<" Your answer is incorrect"<<endl;
    	st.marks=st.marks-1;	
	}


}
void result() {
	int per;
	cout<<"Student Name = "<<st.Name<<endl;
	cout<<"Student Roll no: = "<<st.roll<<endl;
    cout<<"obtained marks = "<<st.marks<<" out of 20"<<endl;
    cout<<"Percentage = "<<100*st.marks/20<<"%"<<endl;
}
int main()
{
	char press,select;
	do{
			
	cout<<"\t    QUIZ HUB"<<endl;
	cout<<"\t****************"<<endl;
	cout<<"\tEnter Your Name : ";
	gets(st.Name);
		cout<<"\tEnter Your Roll no : ";
			gets(st.roll);
			system("CLS");
			cout<<"* Marks less than 50% will be fail."<<endl;
			cout<<"* Correct answer add 4 points to balance and incorrect minus 1 from balance."<<endl;
			cout<<"* Which test do you want?"<<endl;
		cout<<"1) Mathematics "<<endl;
		cout<<"2) English "<<endl;
		cout<<"3) Physics "<<endl;
	   select=getch();
	   system("cls");
	   switch(select)
	   {
	   	case '1':
	   		cout<<"    Mathematics quiz"<<endl;
	   		cout<<" **********************"<<endl;
	   	math();
	   	system("cls");
	   	 	result();
	   	break;
	   	case '2':
	   		cout<<"    English quiz"<<endl;
	   		cout<<" **********************"<<endl;
	   	eng();
	   	system("cls");
	   	result();
	   	break;
	   	case '3':
	   		cout<<"    Physics quiz"<<endl;
	   		cout<<" **********************"<<endl;
		phy();
		system("cls");
		 	result();
	   	break;
	   	default:
	   		cout<<"Invalid choice";
	   }
		cout<<"Enter A to continue and any key to finish"<<endl;
		press=getch();
		system("cls");
		
	}
	
	while(press=='a'||press=='A');
	
	
	
}
